package day01;

public class UserInfo {

	public static void main(String[] args) {
		Mypage2 my=new Mypage2();
		
		System.out.println("전체 회원의 정보입니다"); //전체회원 객체 생성, 정보 출력하기
		
		
		
		
		
		
		
	

	}

}
