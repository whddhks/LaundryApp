package day01;

public class MyPage {

	public static void main(String[] args) {

		
		
		
		
	}

}
