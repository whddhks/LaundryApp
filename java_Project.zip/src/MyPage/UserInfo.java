package MyPage;

public class UserInfo {

	private int name;
	private int phone;
	private int add;
	
	public int getName() {
		return name;
	}
	
	public void setName(int name) {
		this.name= name;
	}
	
	//----------------------------
	
	public int phone() {
		return phone;
	}
	
	public void setphone(int phone) {
		this.phone=phone;
	}
	//----------------------------
	
	public int getadd() {
		return add;
	}
	
	public void setadd(int add) {
		this.add= add;
	}
	
	
	
	
	
		
		
		
		
		
		
		
	

	}

}
