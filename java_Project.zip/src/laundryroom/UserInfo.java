package laundryroom;
import java.util.*;
public class UserInfo  {
	
	/*public UserInfo(String id, int password, String name, String address, int phoneNumber) {
		super(id, password, name, address, phoneNumber);}*/
	
	
		
	}
	public void ShowInfo() {
		System.out.println("등록하신 ID는 "+getId()+" 입니다.");
		System.out.println("등록하신 성함은 "+getName()+"님 입니다.");
		System.out.println("등록하신 연락처는 "+getPhoneNumber()+" 입니다.");
		System.out.println("등록하신 주소는 "+getAddress()+"입니다.");
	}
	
	

}
