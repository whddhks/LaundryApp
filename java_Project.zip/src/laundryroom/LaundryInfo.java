package laundryroom;
import java.util.*;
/** 사용자가 맡길 세탁물을 등록하는 클래스 입니다.
 * 
 */


		
//메뉴선택에서 잘못 입력했을 경우 무게입력이 먼저 뜨는데
		//이게 먼저뜨게 할려면 어떻게 해야 할까요?
	
//	public static void StandardRegister() {
//		Scanner sc=new Scanner(System.in);
//		
//		LaundryInfo li=new LaundryInfo();//LaundryInfo의 변수 li
//		System.out.println("--표준 세탁--");
//		System.out.println();
//		li.setType(sc.next());
//		System.out.println("세탁물의 무게를 입력해주세요");
//		li.setWeight(sc.nextInt());
//		li.setPrice(1000);
//		System.out.println("등록이 완료되었습니다.");
//	}
//	
//	public static void DryRegister() {
//		Scanner sc=new Scanner(System.in);
//		LaundryInfo li=new LaundryInfo();//LaundryInfo의 변수 li
//		System.out.println("--드라이 클리닝--");
//		li.setType(sc.next());
//		System.out.println("갯수를 입력해주세요");
//		li.setWeight(sc.nextInt());
//		li.setPrice(5000);
//		System.out.println("등록이 완료되었습니다.");
//
//	}
//	
//	public static void BeddingRegister() {
//		Scanner sc=new Scanner(System.in);
//		LaundryInfo li=new LaundryInfo();//LaundryInfo의 변수 li
//		System.out.println("--이불 세탁--");
//		li.setType(sc.next());
//		System.out.println("세탁물의 무게를 입력해주세요");
//		li.setWeight(sc.nextInt());
//		li.setPrice(3000);
//		System.out.println("등록이 완료되었습니다.");
//
//	}

}
